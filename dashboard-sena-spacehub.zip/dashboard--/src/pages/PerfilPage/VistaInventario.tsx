import React, { useState } from 'react';
import { Equipo, Role } from '../../types';
import { opcionesRam } from '../../data/seedData';

interface VistaInventarioProps {
  role: Role;
  equipos: Equipo[];
  onAgregarEquipo: (equipo: Equipo) => void;
  onEliminarEquipo: (placa: string) => void;
}

export const VistaInventario: React.FC<VistaInventarioProps> = ({ role, equipos, onAgregarEquipo, onEliminarEquipo }) => {
  const [mostrarForm, setMostrarForm] = useState(false);
  const [placa, setPlaca] = useState('');
  const [modelo, setModelo] = useState('');
  const [spec, setSpec] = useState(opcionesRam[0]);

  const esAdmin = role === 'admin';

  const handleSubmit = () => {
    if (!placa.trim() || !modelo.trim()) return;
    onAgregarEquipo({ placa: placa.trim(), modelo: modelo.trim(), spec, estado: 'Operativo' });
    setPlaca('');
    setModelo('');
    setSpec(opcionesRam[0]);
    setMostrarForm(false);
  };

  return (
    <div className="view-container">
      <div className="view-header">
        <div>
          <h2>Inventario de Equipos de Cómputo</h2>
          <p>Control individualizado por Placa SENA e Interface `EquipoData`</p>
        </div>
        {esAdmin && (
          <button className="btn-primary" onClick={() => setMostrarForm((v) => !v)}>
            + Registrar Nuevo Equipo
          </button>
        )}
      </div>

      {esAdmin && mostrarForm && (
        <div className="form-box">
          <span className="form-box-title">FORMULARIO: NUEVO EQUIPO (INTERFACE `EQUIPODATA`)</span>
          <div className="form-row">
            <input
              className="form-input"
              placeholder="Placa SENA (ej. SENA-8942)"
              value={placa}
              onChange={(e) => setPlaca(e.target.value)}
            />
            <input
              className="form-input"
              placeholder="Marca / Modelo (ej. Lenovo ThinkPad L14)"
              value={modelo}
              onChange={(e) => setModelo(e.target.value)}
            />
            <select className="form-input" value={spec} onChange={(e) => setSpec(e.target.value)}>
              {opcionesRam.map((op) => (
                <option key={op} value={op}>{op}</option>
              ))}
            </select>
          </div>
          <div className="form-actions">
            <button className="btn-secondary" onClick={() => setMostrarForm(false)}>Cancelar</button>
            <button className="btn-primary" onClick={handleSubmit}>Guardar Equipo</button>
          </div>
        </div>
      )}

      <div className="table-wrapper">
        <table className="inventory-table">
          <thead>
            <tr>
              <th>Placa SENA</th>
              <th>Equipo / Modelo</th>
              <th>Especificación</th>
              <th>Estado</th>
              <th className="text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {equipos.map((item) => (
              <tr key={item.placa}>
                <td className="placa-code">{item.placa}</td>
                <td className="font-bold">{item.modelo}</td>
                <td>{item.spec}</td>
                <td>
                  <span className={`status-pill ${item.estado === 'Operativo' ? 'ok' : 'warn'}`}>
                    {item.estado}
                  </span>
                </td>
                <td className="text-right">
                  {esAdmin ? (
                    <button className="btn-link-danger" onClick={() => onEliminarEquipo(item.placa)}>
                      Eliminar
                    </button>
                  ) : (
                    <span className="muted-text">Solo Operarios</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default VistaInventario;
