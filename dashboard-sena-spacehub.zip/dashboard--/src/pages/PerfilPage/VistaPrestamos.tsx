import React, { useState } from 'react';
import { Equipo, Prestamo, Role, Usuario } from '../../types';
import { TarjetaFicha } from '../../components/TarjetaFicha/TarjetaFicha';

interface VistaPrestamosProps {
  role: Role;
  usuario: Usuario;
  equipos: Equipo[];
  prestamos: Prestamo[];
  onCrearPrestamo: (p: Omit<Prestamo, 'id' | 'hora'>) => void;
  onDevolver: (id: number) => void;
}

export const VistaPrestamos: React.FC<VistaPrestamosProps> = ({
  role,
  usuario,
  equipos,
  prestamos,
  onCrearPrestamo,
  onDevolver,
}) => {
  const esAdmin = role === 'admin';
  const [mostrarForm, setMostrarForm] = useState(false);

  const equiposDisponibles = equipos.filter(
    (e) => e.estado === 'Operativo' && !prestamos.some((p) => p.equipoPlaca === e.placa)
  );

  const [nombre, setNombre] = useState(esAdmin ? '' : usuario.nombre);
  const [ficha, setFicha] = useState(esAdmin ? '' : usuario.ficha);
  const [equipoPlaca, setEquipoPlaca] = useState(equiposDisponibles[0]?.placa ?? '');

  const abrirForm = () => {
    setNombre(esAdmin ? '' : usuario.nombre);
    setFicha(esAdmin ? '' : usuario.ficha);
    setEquipoPlaca(equiposDisponibles[0]?.placa ?? '');
    setMostrarForm(true);
  };

  const handleSubmit = () => {
    if (!nombre.trim() || !ficha.trim() || !equipoPlaca) return;
    onCrearPrestamo({ nombre: nombre.trim(), ficha: ficha.trim(), equipoPlaca });
    setMostrarForm(false);
  };

  return (
    <div className="view-container">
      <div className="view-header">
        <div>
          <h2>Gestión de Solicitudes de Préstamo</h2>
          <p>Control de entregas y devoluciones para aprendices e instructores</p>
        </div>
        <button className="btn-primary" onClick={abrirForm}>
          📄 Solicitar Préstamo de Equipo
        </button>
      </div>

      {mostrarForm && (
        <div className="form-box">
          <div className="form-box-header">
            <span className="form-box-title">FORMULARIO: NUEVA SOLICITUD (INTERFACE `PRESTAMODATA`)</span>
            {esAdmin && <span className="pill-info">Modo Gestión Operario</span>}
          </div>

          {esAdmin ? (
            <div className="form-note">
              🛠 Modo Operario / Administrador: Puedes registrar la entrega física de un equipo ingresando los datos del aprendiz solicitante.
            </div>
          ) : (
            <div className="form-note">
              🎓 Modo Aprendiz: tus datos se autocompletan con tu ficha activa.
            </div>
          )}

          <div className="form-grid-3">
            <div>
              <label className="form-label">Aprendiz Solicitante:</label>
              <input
                className="form-input"
                value={nombre}
                disabled={!esAdmin}
                onChange={(e) => setNombre(e.target.value)}
              />
            </div>
            <div>
              <label className="form-label">Número de Ficha SENA:</label>
              <input
                className="form-input"
                value={ficha}
                disabled={!esAdmin}
                onChange={(e) => setFicha(e.target.value)}
              />
            </div>
            <div>
              <label className="form-label">Equipo Requerido (Placa SENA):</label>
              <select className="form-input" value={equipoPlaca} onChange={(e) => setEquipoPlaca(e.target.value)}>
                {equiposDisponibles.length === 0 && <option value="">Sin equipos disponibles</option>}
                {equiposDisponibles.map((eq) => (
                  <option key={eq.placa} value={eq.placa}>
                    {eq.placa} - {eq.modelo} ({eq.spec})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-actions">
            <button className="btn-secondary" onClick={() => setMostrarForm(false)}>Cancelar</button>
            <button className="btn-primary" onClick={handleSubmit} disabled={!equipoPlaca}>
              Confirmar Solicitud de Préstamo
            </button>
          </div>
        </div>
      )}

      <div className="cards-grid">
        {prestamos.map((p) => (
          <TarjetaFicha
            key={p.id}
            ficha={p.ficha}
            hora={p.hora}
            nombre={p.nombre}
            equipo={p.equipoPlaca}
            onDevolucion={esAdmin ? () => onDevolver(p.id) : undefined}
            soloOperarios={!esAdmin}
          />
        ))}
        {prestamos.length === 0 && <p className="muted-text">No hay préstamos activos.</p>}
      </div>
    </div>
  );
};

export default VistaPrestamos;
