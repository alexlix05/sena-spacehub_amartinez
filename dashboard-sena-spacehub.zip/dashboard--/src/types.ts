export type Role = 'aprendiz' | 'admin';

export type TabType = 'dashboard' | 'inventario' | 'prestamos' | 'ticketera';

export type EstadoEquipo = 'Operativo' | 'En Mantenimiento';

export interface Equipo {
  placa: string;
  modelo: string;
  spec: string;
  estado: EstadoEquipo;
}

export interface Prestamo {
  id: number;
  ficha: string;
  nombre: string;
  hora: string;
  equipoPlaca: string;
}

export type Prioridad = 'Alta' | 'Media' | 'Baja';

export interface Ticket {
  id: number;
  placa: string;
  descripcion: string;
  prioridad: Prioridad;
  resuelto: boolean;
}

export interface Usuario {
  nombre: string;
  ficha: string;
  correo: string;
  role: Role;
}
