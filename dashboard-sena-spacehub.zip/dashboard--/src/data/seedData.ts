import { Equipo, Prestamo, Ticket, Usuario } from '../types';

export const usuarioAprendiz: Usuario = {
  nombre: 'Ana María Fajardo',
  ficha: '2879451',
  correo: 'ana.fajardo@sena.edu.co',
  role: 'aprendiz',
};

export const usuarioAdmin: Usuario = {
  nombre: 'Ing. Roberto Gómez',
  ficha: '—',
  correo: 'roberto.gomez@sena.edu.co',
  role: 'admin',
};

export const equiposIniciales: Equipo[] = [
  { placa: 'SENA-1001', modelo: 'Lenovo ThinkPad L14 G3', spec: '16GB DDR4', estado: 'Operativo' },
  { placa: 'SENA-1002', modelo: 'HP ProBook 440 G8', spec: '16GB DDR4', estado: 'En Mantenimiento' },
  { placa: 'SENA-1003', modelo: 'Dell Latitude 3420', spec: '32GB DDR5', estado: 'Operativo' },
  { placa: 'SENA-1004', modelo: 'Lenovo ThinkPad L14 G3', spec: '16GB DDR4', estado: 'Operativo' },
  { placa: 'SENA-1005', modelo: 'ASUS ExpertBook P2', spec: '8GB DDR4', estado: 'Operativo' },
];

export const prestamosIniciales: Prestamo[] = [
  { id: 1, ficha: '2879451', nombre: 'Ana María Fajardo', hora: '08:00 AM', equipoPlaca: 'SENA-1001' },
  { id: 2, ficha: '2879451', nombre: 'Carlos Mendoza', hora: '09:30 AM', equipoPlaca: 'SENA-1003' },
  { id: 3, ficha: '2879432', nombre: 'Jennifer Andrea', hora: '10:15 AM', equipoPlaca: 'SENA-1004' },
];

export const ticketsIniciales: Ticket[] = [
  { id: 1, placa: 'SENA-1002', descripcion: 'Falla en el teclado y puerto HDMI intermitente', prioridad: 'Alta', resuelto: false },
  { id: 2, placa: 'SENA-1005', descripcion: 'Batería no retiene carga más de 30 minutos', prioridad: 'Media', resuelto: false },
];

export const opcionesRam = ['16GB RAM DDR4', '32GB RAM DDR5', '8GB RAM DDR4'];
