import React from 'react';
import { TabType, Usuario } from '../../types';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  usuario: Usuario;
  onSalir: () => void;
  counts: {
    inventario: number;
    prestamos: number;
    ticketera: number;
  };
}

export const SenaHeader: React.FC<HeaderProps> = ({ activeTab, setActiveTab, usuario, onSalir, counts }) => {
  return (
    <header className="sena-header">
      <div className="header-left">
        <span className="badge-sena">SENA SpaceHub</span>
        <span className="sub-text">Centro de Gestión de Mercados, Logística y TI</span>
      </div>

      <nav className="header-nav">
        <button
          className={`nav-btn ${activeTab === 'dashboard' ? 'active-green' : ''}`}
          onClick={() => setActiveTab('dashboard')}
        >
          📊 Dashboard
        </button>
        <button
          className={`nav-btn ${activeTab === 'inventario' ? 'active-green' : ''}`}
          onClick={() => setActiveTab('inventario')}
        >
          📦 Inventario ({counts.inventario})
        </button>
        <button
          className={`nav-btn ${activeTab === 'prestamos' ? 'active-green' : ''}`}
          onClick={() => setActiveTab('prestamos')}
        >
          💾 Préstamos ({counts.prestamos})
        </button>
        <button
          className={`nav-btn ${activeTab === 'ticketera' ? 'active-green' : ''}`}
          onClick={() => setActiveTab('ticketera')}
        >
          🛠 Ticketera ({counts.ticketera})
        </button>
      </nav>

      <div className="header-user">
        <span className="dot-online">🟢</span>
        <span className="user-name">{usuario.nombre}</span>
        <span className={`badge-role ${usuario.role}`}>
          {usuario.role === 'admin' ? 'Administrador' : 'Aprendiz'}
        </span>
        <button className="btn-logout" onClick={onSalir}>Salir</button>
      </div>
    </header>
  );
};

export default SenaHeader;
