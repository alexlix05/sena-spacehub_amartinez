import React, { useState } from 'react';
import './LoginModal.css';
import { Role } from '../../types';
import { usuarioAprendiz } from '../../data/seedData';

interface LoginModalProps {
  onSelectRole: (role: Role) => void;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onSelectRole, onClose }) => {
  const [correo, setCorreo] = useState(usuarioAprendiz.correo);
  const [password, setPassword] = useState('••••••••');

  const handleAutenticar = () => {
    const esAdmin = correo.toLowerCase().includes('roberto');
    onSelectRole(esAdmin ? 'admin' : 'aprendiz');
  };

  return (
    <div className="login-modal-overlay">
      <div className="login-modal">
        <div className="login-modal-header">
          <h3>🔒 INICIAR SESIÓN RÁPIDA (PROBAR ROLES)</h3>
          <button className="login-modal-close" onClick={onClose}>✕</button>
        </div>
        <p className="login-modal-subtitle">
          Selecciona un usuario de prueba para cambiar de contexto inmediatamente
        </p>

        <hr className="login-modal-divider" />

        <span className="login-modal-label">Probar como:</span>

        <button className="login-role-card" onClick={() => onSelectRole('aprendiz')}>
          <div className="login-role-info">
            <span className="login-role-icon">🎓</span>
            <div>
              <div className="login-role-name aprendiz">Ana María Fajardo</div>
              <div className="login-role-desc">Rol: Aprendiz ADSO • Ficha 2879451</div>
            </div>
          </div>
          <span className="login-role-badge aprendiz">Aprendiz</span>
        </button>

        <button className="login-role-card" onClick={() => onSelectRole('admin')}>
          <div className="login-role-info">
            <span className="login-role-icon">👤</span>
            <div>
              <div className="login-role-name admin">Ing. Roberto Gómez (Operario/Admin)</div>
              <div className="login-role-desc">Rol: Administrador • Gestión Total</div>
            </div>
          </div>
          <span className="login-role-badge admin">Admin</span>
        </button>

        <div className="login-modal-or">
          <span>O ingresa manualmente</span>
        </div>

        <label className="login-field-label">Correo Institucional (@sena.edu.co):</label>
        <input
          className="login-field-input"
          type="text"
          value={correo}
          onChange={(e) => setCorreo(e.target.value)}
        />

        <label className="login-field-label">Contraseña:</label>
        <input
          className="login-field-input"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <div className="login-modal-actions">
          <button className="btn-login-cancel" onClick={onClose}>Cancelar</button>
          <button className="btn-login-confirm" onClick={handleAutenticar}>Autenticar (JWT)</button>
        </div>
      </div>
    </div>
  );
};

export default LoginModal;
