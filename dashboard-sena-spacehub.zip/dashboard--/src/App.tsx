import { useState } from "react";
import "./App.css";
import { SenaHeader } from "./components/SenaHeader/SenaHeader";
import { LoginModal } from "./components/LoginModal/LoginModal";

import { VistaDashboard } from "./pages/PerfilPage/VistaDashboard";
import { VistaInventario } from "./pages/PerfilPage/VistaInventario";
import { VistaTicketera } from "./pages/PerfilPage/VistaTicketera";
import { VistaPrestamos } from "./pages/PerfilPage/VistaPrestamos";

import { Equipo, Prestamo, Role, TabType, Ticket } from "./types";
import {
  equiposIniciales,
  prestamosIniciales,
  ticketsIniciales,
  usuarioAdmin,
  usuarioAprendiz,
} from "./data/seedData";

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [role, setRole] = useState<Role>('aprendiz');
  const [showLogin, setShowLogin] = useState(true);

  const [equipos, setEquipos] = useState<Equipo[]>(equiposIniciales);
  const [prestamos, setPrestamos] = useState<Prestamo[]>(prestamosIniciales);
  const [tickets, setTickets] = useState<Ticket[]>(ticketsIniciales);

  const usuario = role === 'admin' ? usuarioAdmin : usuarioAprendiz;

  const handleSelectRole = (r: Role) => {
    setRole(r);
    setShowLogin(false);
  };

  const handleAgregarEquipo = (equipo: Equipo) => {
    setEquipos((prev) => [...prev, equipo]);
  };

  const handleEliminarEquipo = (placa: string) => {
    setEquipos((prev) => prev.filter((e) => e.placa !== placa));
  };

  const handleCrearPrestamo = (p: Omit<Prestamo, 'id' | 'hora'>) => {
    const hora = new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });
    setPrestamos((prev) => [...prev, { ...p, id: Date.now(), hora: `${hora} (ahora)` }]);
  };

  const handleDevolver = (id: number) => {
    setPrestamos((prev) => prev.filter((p) => p.id !== id));
  };

  const handleCrearTicket = (t: Omit<Ticket, 'id' | 'resuelto'>) => {
    setTickets((prev) => [...prev, { ...t, id: Date.now(), resuelto: false }]);
  };

  const handleResolver = (id: number) => {
    setTickets((prev) => prev.map((t) => (t.id === id ? { ...t, resuelto: true } : t)));
  };

  const counts = {
    inventario: equipos.length,
    prestamos: prestamos.length,
    ticketera: tickets.filter((t) => !t.resuelto).length,
  };

  return (
    <div className="main-layout">
      <SenaHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        usuario={usuario}
        onSalir={() => setShowLogin(true)}
        counts={counts}
      />

      <div className="role-banner">
        {role === 'aprendiz' ? (
          <span>🎓 Modo Aprendiz ADSO activo (Ficha: {usuario.ficha}). Las solicitudes de préstamo autocompletan tus datos personales.</span>
        ) : (
          <span>🛠 Modo Administrador / Operario de Cómputo activo. Tienes permisos para agregar equipos al inventario y asignar préstamos a cualquier aprendiz.</span>
        )}
        <button className="btn-link" onClick={() => setRole(role === 'aprendiz' ? 'admin' : 'aprendiz')}>
          ⚡ Cambiar a {role === 'aprendiz' ? 'Operador/Admin' : 'Aprendiz'}
        </button>
      </div>

      <main className="content-area">
        {activeTab === 'dashboard' && (
          <VistaDashboard equipos={equipos} prestamos={prestamos} tickets={tickets} />
        )}
        {activeTab === 'inventario' && (
          <VistaInventario
            role={role}
            equipos={equipos}
            onAgregarEquipo={handleAgregarEquipo}
            onEliminarEquipo={handleEliminarEquipo}
          />
        )}
        {activeTab === 'prestamos' && (
          <VistaPrestamos
            role={role}
            usuario={usuario}
            equipos={equipos}
            prestamos={prestamos}
            onCrearPrestamo={handleCrearPrestamo}
            onDevolver={handleDevolver}
          />
        )}
        {activeTab === 'ticketera' && (
          <VistaTicketera
            role={role}
            equipos={equipos}
            tickets={tickets}
            onCrearTicket={handleCrearTicket}
            onResolver={handleResolver}
          />
        )}
      </main>

      {showLogin && (
        <LoginModal onSelectRole={handleSelectRole} onClose={() => setShowLogin(false)} />
      )}
    </div>
  );
}

export default App;
